import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

import exchange_calendars as xc

base=Path(__file__).resolve().parent.parent
dest=base/'outputs/Equity-calendar-v1-1-source-20261024'
dest.mkdir(exist_ok=False)
start,end='2008-12-01','2026-10-01'
calendar=xc.get_calendar('XNYS',start=start,end='2026-11-10')
calendar.schedule.to_csv(dest/'calendar.csv',index_label='session')
sessions=[x.strftime('%Y-%m-%d') for x in calendar.sessions if start<=x.strftime('%Y-%m-%d')<end]
manifest={'provider':'Yahoo public chart JSON','calendar_package':xc.__version__,'symbols':{},'start':start,'end_exclusive':end,'session_count':len(sessions)}
for symbol in ('SPY','SHV'):
    params={'period1':int(datetime.fromisoformat(start).replace(tzinfo=timezone.utc).timestamp()),'period2':int(datetime.fromisoformat(end).replace(tzinfo=timezone.utc).timestamp()),'interval':'1d','events':'div,splits','includeAdjustedClose':'true'}
    url='https://query1.finance.yahoo.com/v8/finance/chart/'+symbol+'?'+urlencode(params)
    previous=base/'outputs/Equity-calendar-v1-source-20261024/SPY-raw.json'
    if symbol=='SPY':
        raw=previous.read_bytes()
    else:
        with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as stream:
            raw=stream.read()
    (dest/(symbol+'-raw.json')).write_bytes(raw)
    payload=json.loads(raw)
    if payload['chart'].get('error'):
        raise ValueError(payload['chart']['error'])
    r=payload['chart']['result'][0]
    if r.get('events',{}).get('splits'):
        raise ValueError('split present; reject unmodeled share action')
    q=r['indicators']['quote'][0]
    dates=[datetime.fromtimestamp(t,ZoneInfo('America/New_York')).date().isoformat() for t in r['timestamp']]
    if dates!=sessions:
        raise ValueError(f'{symbol}: vendor/calendar mismatch {set(dates)^set(sessions)}')
    rows=[dict(date=day,**{k:q[k][i] for k in ('open','high','low','close','volume')}) for i,day in enumerate(dates)]
    with (dest/(symbol+'.csv')).open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    divs=[]
    for item in r.get('events',{}).get('dividends',{}).values():
        divs.append({'ex_date':datetime.fromtimestamp(item['date'],ZoneInfo('America/New_York')).date().isoformat(),'amount':item['amount']})
    (dest/(symbol+'-dividends.json')).write_text(json.dumps(sorted(divs,key=lambda x:x['ex_date']),indent=2)+'\n',encoding='utf-8')
    manifest['symbols'][symbol]={'url':url,'raw_sha256':hashlib.sha256(raw).hexdigest(),'bars':len(rows),'dividend_events':len(divs),'splits':0,'exchange_timezone':r['meta']['exchangeTimezoneName']}
for path in dest.iterdir():
    if path.is_file():
        manifest.setdefault('files',[]).append({'name':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'folder':str(dest),'session_count':len(sessions),'symbols':{k:{'bars':v['bars'],'dividend_events':v['dividend_events']} for k,v in manifest['symbols'].items()}}))
