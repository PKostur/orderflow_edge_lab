import csv
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

base=Path(__file__).resolve().parent.parent
old=base/'outputs/Equity-calendar-v1-1-source-20261024'
dest=base/'outputs/Four-regime-v1-source-20261024'
dest.mkdir(exist_ok=False)
for name in ('calendar.csv','planned_calendar.csv','SPY.csv','SPY-raw.json','SPY-dividends.json','SHV.csv','SHV-raw.json','SHV-dividends.json'):
    shutil.copyfile(old/name,dest/name)
previous=json.loads((old/'manifest.json').read_text())
manifest={k:v for k,v in previous.items() if k!='files'}
manifest['symbols']=dict(previous['symbols'])
with (dest/'SPY.csv').open() as stream:
    expected=[r['date'] for r in csv.DictReader(stream)]
for symbol in ('TLT','GLD'):
    params={'period1':int(datetime(2008,12,1,tzinfo=timezone.utc).timestamp()),'period2':int(datetime(2026,10,1,tzinfo=timezone.utc).timestamp()),'interval':'1d','events':'div,splits','includeAdjustedClose':'true'}
    url='https://query1.finance.yahoo.com/v8/finance/chart/'+symbol+'?'+urlencode(params)
    with urlopen(Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=30) as stream:
        raw=stream.read()
    (dest/(symbol+'-raw.json')).write_bytes(raw)
    payload=json.loads(raw)
    if payload['chart'].get('error'):
        raise ValueError(payload['chart']['error'])
    r=payload['chart']['result'][0]
    if r.get('events',{}).get('splits'):
        raise ValueError('unmodeled split; no further asset substitutions')
    q=r['indicators']['quote'][0]
    dates=[datetime.fromtimestamp(t,ZoneInfo('America/New_York')).date().isoformat() for t in r['timestamp']]
    if dates!=expected:
        raise ValueError('unaligned source/calendar')
    rows=[dict(date=d,**{k:q[k][i] for k in ('open','high','low','close','volume')}) for i,d in enumerate(dates)]
    with (dest/(symbol+'.csv')).open('w',newline='',encoding='utf-8') as stream:
        w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    divs=[{'ex_date':datetime.fromtimestamp(x['date'],ZoneInfo('America/New_York')).date().isoformat(),'amount':x['amount']} for x in r.get('events',{}).get('dividends',{}).values()]
    (dest/(symbol+'-dividends.json')).write_text(json.dumps(sorted(divs,key=lambda x:x['ex_date']),indent=2)+'\n',encoding='utf-8')
    manifest['symbols'][symbol]={'url':url,'raw_sha256':hashlib.sha256(raw).hexdigest(),'bars':len(rows),'dividend_events':len(divs),'splits':0,'exchange_timezone':r['meta']['exchangeTimezoneName']}
manifest['files']=[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(dest.iterdir()) if p.is_file()]
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'folder':str(dest),'symbols':{s:{'bars':x['bars'],'dividends':x['dividend_events']} for s,x in manifest['symbols'].items()}}))
