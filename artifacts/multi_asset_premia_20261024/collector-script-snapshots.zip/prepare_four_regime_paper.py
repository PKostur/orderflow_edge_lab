import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path

import exchange_calendars as xc
from orderflow_edge_lab.four_regime_paper import fetch_quotes,make_intent,verify_intent

base=Path(__file__).resolve().parent.parent
repo=base/'work/orderflow_edge_lab'
dest=repo/'artifacts/four_regime_forward_operational_v1'
dest.mkdir(exist_ok=False)
calendar=xc.get_calendar('XNYS',start='2026-01-01',end='2027-12-31')
calendar.schedule.to_csv(dest/'calendar.csv',index_label='session')
protocol=json.loads((repo/'config/four_regime_forward_operational_v1.json').read_text())
reference={'reference_session':protocol['reference_session'],'closes':{},'raw_receipts':[]}
for asset in ('SPY','TLT','GLD','SHV'):
    prices,_,receipt=fetch_quotes(asset,'2026-10-23','2026-10-24',dest)
    if '2026-10-23' not in prices:
        raise ValueError('missing complete previous session')
    reference['closes'][asset]=prices['2026-10-23']['close']
    reference['raw_receipts'].append(receipt)
reference['captured_at_utc']=datetime.now(timezone.utc).isoformat()
intent=make_intent(reference,protocol)
verify_intent(intent)
path=repo/'config/four_regime_paper_intent_v1.json'
if path.exists():
    raise FileExistsError('intent already frozen')
path.write_text(json.dumps(intent,indent=2,allow_nan=False)+'\n',encoding='utf-8')
(dest/'reference.json').write_text(json.dumps(reference,indent=2,allow_nan=False)+'\n',encoding='utf-8')
index={'intent_sha256':intent['intent_sha256'],'files':[{'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(dest.iterdir()) if p.is_file()]}
(dest/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'intent':str(path),'scheduled_entry_utc':protocol['initial_open_utc'],'intent_sha256':intent['intent_sha256'],'accounts':intent['accounts']},indent=2))
